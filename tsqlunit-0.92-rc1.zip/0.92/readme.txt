Project
-------
tsqlunit

A xUnit testing framework for Microsoft SQL Server.

Home page: 

http://tsqlunit.sourceforge.net


Subscribe to the announce list if you want to hear about new versions.

http://lists.sourceforge.net/mailman/listinfo/tsqlunit-announce


Installation
------------
1. Unzip the file.Unzip the file. You can use winzip or the open source 7-zip. 
2. Connect to your database as dbo using the SQL Query Analyzer, execute the tsqlunit.sql file. 


Remove
------
1. Connect to your database as dbo using the SQL Query Analyzer, execute the removetsqlunit.sql file.


Author
------
Henrik Ekelund, email: <http://sourceforge.net/sendmessage.php?touser=618411>


License
-------
LGPL, see http://www.opensource.org/licenses/lgpl-license.php


Documentation
-------------
See home page


Contribute
----------
Please use the system available on the homepage for reporting bugs and to request features.

Improvements and comments may also be sent to the author. 

Discuss using the users mailing list at http://lists.sourceforge.net/lists/listinfo/tsqlunit-users


Relase history
--------------
0.9 Is the first release

